from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os
import uuid

# Optional: Fix warning related to TensorFlow optimizations
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

app = Flask(__name__)

# Load the trained model
model = load_model("breast_cancer_cnn_model.h5")  # .h5 ka file

# Define class labels
class_names = ['Benign', 'Malignant']

# Preprocess uploaded image
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0
    return img_array

# Homepage
@app.route("/", methods=["GET", "POST"])
def index():
    prediction_result = None
    image_path = None

    if request.method == "POST":
        file = request.files["file"]
        if file:
            filename = str(uuid.uuid4()) + os.path.splitext(file.filename)[1]
            file_path = os.path.join("static", filename)
            file.save(file_path)

            # Predict
            processed_img = preprocess_image(file_path)
            prediction = model.predict(processed_img)

            # Since output is 2 classes
            predicted_class = np.argmax(prediction[0])
            prediction_result = class_names[predicted_class]
            image_path = filename

    return render_template("index.html", result=prediction_result, image_path=image_path)

if __name__ == "__main__":
    app.run(debug=True)
